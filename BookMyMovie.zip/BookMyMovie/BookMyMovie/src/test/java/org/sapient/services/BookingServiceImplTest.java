package org.sapient.services;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.sapient.dto.BookingDTO;
import org.sapient.entities.Booking;
import org.sapient.entities.Movie;
import org.sapient.entities.Seat;
import org.sapient.entities.Show;
import org.sapient.enums.BookingStatus;
import org.sapient.exception.ResourceNotFoundException;
import org.sapient.model.BookingRequest;
import org.sapient.repository.BookingRepository;
import org.sapient.repository.ShowRepository;
import org.sapient.services.impl.BookingServiceImpl;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class BookingServiceImplTest {

    @Mock
    private SeatService seatService;

    @Mock
    private BookingRepository bookingRepository;

    @Mock
    private ShowRepository showRepository;

    @Mock
    private PaymentService paymentService;

    @InjectMocks
    private BookingServiceImpl bookingService;

    private BookingRequest bookingRequest;
    private Show show;
    private List<Seat> seats;
    private Booking savedBooking;

    @BeforeEach
    void setUp() {
        // Setup test data
        bookingRequest = new BookingRequest();
        bookingRequest.setShowId(1L);
        bookingRequest.setSeatNumbers(Arrays.asList(1L, 2L));

        Movie movie = new Movie();
        movie.setMovieId(1L);
        movie.setMovieName("Test Movie");

        show = new Show();
        show.setShowId(1L);
        show.setMovie(movie);
        show.setShowStartTime(String.valueOf(LocalDateTime.now().plusHours(2)));
        show.setShowDate(LocalDate.now());

        Seat seat1 = new Seat();
        seat1.setSeatId(1L);
        seat1.setPrice(100.0);

        Seat seat2 = new Seat();
        seat2.setSeatId(2L);
        seat2.setPrice(100.0);

        seats = Arrays.asList(seat1, seat2);

        savedBooking = new Booking();
        savedBooking.setId("BK12345678");
        savedBooking.setShowId(1L);
        savedBooking.setMovieName("Test Movie");
        savedBooking.setBookingTime(LocalDateTime.now());
        savedBooking.setBookingStatus(BookingStatus.CONFIRMED);
        savedBooking.setTotalAmount(200.0);
        savedBooking.setShowStartTime(show.getShowStartTime());
        savedBooking.setShowDate(show.getShowDate());
        savedBooking.setSeatNumbers(Arrays.asList(1L, 2L));
    }

    @Test
    void initiateBooking_Success() {
        // Arrange
        when(showRepository.findById(bookingRequest.getShowId())).thenReturn(Optional.of(show));
        when(seatService.getSeatsByIds(bookingRequest.getSeatNumbers())).thenReturn(seats);
        when(paymentService.processPayment(seats)).thenReturn(200.0);
        when(bookingRepository.save(any(Booking.class))).thenReturn(savedBooking);
        doNothing().when(seatService).lockSeats(show.getShowId(), seats);
        doNothing().when(seatService).confirmSeats(show.getShowId(), seats);

        // Act
        BookingDTO result = bookingService.initiateBooking(bookingRequest);

        // Assert
        assertNotNull(result);
        assertEquals(savedBooking.getId(), result.getBookingId());
        assertEquals(BookingStatus.CONFIRMED, result.getBookingStatus());
        assertEquals(savedBooking.getTotalAmount(), result.getTotalAmount());

        // Verify method calls
        verify(showRepository).findById(bookingRequest.getShowId());
        verify(seatService).getSeatsByIds(bookingRequest.getSeatNumbers());
        verify(seatService).lockSeats(show.getShowId(), seats);
        verify(paymentService).processPayment(seats);
        verify(bookingRepository).save(any(Booking.class));
        verify(seatService).confirmSeats(show.getShowId(), seats);
    }

    @Test
    void initiateBooking_ShowNotFound() {
        // Arrange
        when(showRepository.findById(bookingRequest.getShowId())).thenReturn(Optional.empty());

        // Act & Assert
        assertThrows(ResourceNotFoundException.class, () -> bookingService.initiateBooking(bookingRequest));

        // Verify method calls
        verify(showRepository).findById(bookingRequest.getShowId());
        verifyNoInteractions(seatService, paymentService, bookingRepository);
    }

    @Test
    void initiateBooking_ExceptionDuringBooking() {
        // Arrange
        when(showRepository.findById(bookingRequest.getShowId())).thenReturn(Optional.of(show));
        when(seatService.getSeatsByIds(bookingRequest.getSeatNumbers())).thenReturn(seats);
        doThrow(new RuntimeException("Seat unavailable")).when(seatService).lockSeats(show.getShowId(), seats);

        // Act & Assert
        assertThrows(RuntimeException.class, () -> bookingService.initiateBooking(bookingRequest));

        // Verify method calls
        verify(showRepository).findById(bookingRequest.getShowId());
        verify(seatService).getSeatsByIds(bookingRequest.getSeatNumbers());
        verify(seatService).lockSeats(show.getShowId(), seats);
        verify(seatService).releaseSeats(show.getShowId(), seats);
        verifyNoInteractions(paymentService, bookingRepository);
    }
}