package org.sapient.controllers;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.sapient.dto.MovieDTO;
import org.sapient.services.MovieService;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
class MovieControllerTest {

    @Mock
    private MovieService movieService;

    @InjectMocks
    private MovieController movieController;

    private MockMvc mockMvc;
    private Long cityId;
    private List<MovieDTO> movieDTOList;

    @BeforeEach
    void setUp() {
        mockMvc = MockMvcBuilders.standaloneSetup(movieController).build();

        // Setup test data
        cityId = 1L;

        MovieDTO movie1 = new MovieDTO();
        movie1.setMovieId(1L);
        movie1.setMovieName("Test Movie 1");

        MovieDTO movie2 = new MovieDTO();
        movie2.setMovieId(2L);
        movie2.setMovieName("Test Movie 2");

        movieDTOList = Arrays.asList(movie1, movie2);
    }

    @Test
    void getMoviesByCity_Success() throws Exception {
        // Arrange
        when(movieService.getMoviesByCity(cityId)).thenReturn(movieDTOList);

        // Act & Assert
        mockMvc.perform(get("/api/v1/movies/city/{cityId}", cityId)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(2))
                .andExpect(jsonPath("$[0].movieId").value(1))
                .andExpect(jsonPath("$[0].movieName").value("Test Movie 1"))
                .andExpect(jsonPath("$[1].movieId").value(2))
                .andExpect(jsonPath("$[1].movieName").value("Test Movie 2"));
    }

    @Test
    void getMoviesByCity_EmptyList() throws Exception {
        // Arrange
        Long emptyCityId = 999L;
        when(movieService.getMoviesByCity(emptyCityId)).thenReturn(Collections.emptyList());

        // Act & Assert
        mockMvc.perform(get("/api/v1/movies/city/{cityId}", emptyCityId)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(0));
    }
}
