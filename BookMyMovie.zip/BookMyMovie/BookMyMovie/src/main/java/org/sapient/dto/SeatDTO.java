package org.sapient.dto;

import lombok.Data;
import org.sapient.enums.SeatCategory;
import org.sapient.enums.SeatStatus;

@Data
public class SeatDTO {

    Long seatId;

    int seatRow;

    SeatCategory seatCategory;

    Boolean isBooked=false;

    SeatStatus seatStatus;

    private double price;
}
