package org.sapient.model;

import lombok.Data;

import java.time.LocalDateTime;

/**
 * Class to represent a seat lock with version and timestamp
 */
@Data
public class SeatLock {
    private final String lockOwner;
    private final long version;
    private final LocalDateTime expiresAt;
    // Lock expiration time in seconds (e.g., 10 minutes)
    private static final long LOCK_EXPIRATION_SECONDS = 600;

    public SeatLock(String lockOwner) {
        this.lockOwner = lockOwner;
        this.version = System.nanoTime();
        this.expiresAt = LocalDateTime.now().plusSeconds(LOCK_EXPIRATION_SECONDS);
    }

    public boolean isExpired() {
        return LocalDateTime.now().isAfter(expiresAt);
    }

}
