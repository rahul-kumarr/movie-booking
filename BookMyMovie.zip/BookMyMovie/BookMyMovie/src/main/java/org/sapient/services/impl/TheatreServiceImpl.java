package org.sapient.services.impl;

import org.sapient.dto.TheatreDTO;
import org.sapient.entities.Theatre;
import org.sapient.exception.NoTheatreFoundException;
import org.sapient.exception.ShowNotFoundException;
import org.sapient.repository.TheatreRepository;
import org.sapient.services.TheatreService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class TheatreServiceImpl implements TheatreService {

    @Autowired
    private TheatreRepository theatreRepository;

    @Override
    @Transactional(readOnly = true,isolation = Isolation.SERIALIZABLE)
    @Cacheable(value = "theatresByCityAndMovie", key = "{#movieId, #cityId}")
    public List<TheatreDTO> getAllTheatres(Long cityId, Long movieId, LocalDate chosenDate) {

        List<Theatre> theatreList = theatreRepository.findByCityIdAndMoviesMovieIdForDate(cityId, movieId, chosenDate);
        if(CollectionUtils.isEmpty(theatreList)){
            throw new NoTheatreFoundException("No theatre in the City is showing selected movie for selected date");
        }
        return mapToDTOList(theatreList);
    }

    public static LocalDate validateSelectedDate(LocalDate chosenDate) {
        if(chosenDate !=null && chosenDate.isBefore(LocalDate.now())){
            throw new ShowNotFoundException("Show for past dates are not listed");
        } else if (chosenDate !=null) {
            chosenDate =LocalDate.now();
        }
        return chosenDate;
    }

    @Override
    @Transactional(readOnly = true)
    @Cacheable(value = "theatresByCity", key = "#cityId")
    public List<TheatreDTO> getAllTheatresInACity(Long cityId) {
        List<Theatre> theatreList = theatreRepository.findByCityId(cityId);
        if(CollectionUtils.isEmpty(theatreList)){
            throw new NoTheatreFoundException("No theatre in the selected City");
        }
        return mapToDTOList(theatreList);
    }

    @Override
    public TheatreDTO getTheTheatreDetail(Long theatreId) {

        Optional<Theatre> theatreById = theatreRepository.findById(theatreId);
        Theatre theatre = theatreById.orElseThrow(() -> new NoTheatreFoundException("Theatre not found with id: " + theatreId));
        return mapToTheatreDTO(theatre);
    }

    private List<TheatreDTO> mapToDTOList(List<Theatre> theatreList){

        List<TheatreDTO> theatreDTOS=new ArrayList<>();

        theatreList.forEach(theatre -> {
            ModelMapper modelMapper = new ModelMapper();
            TheatreDTO theatreDTO = modelMapper.map(theatre, TheatreDTO.class);
            theatreDTOS.add(theatreDTO);
        });
        return theatreDTOS;
    }

    private TheatreDTO mapToTheatreDTO(Theatre theatre){
        ModelMapper modelMapper = new ModelMapper();
        return modelMapper.map(theatre, TheatreDTO.class);
    }

}
