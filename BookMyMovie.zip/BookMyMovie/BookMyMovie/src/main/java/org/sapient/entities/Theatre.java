package org.sapient.entities;



import jakarta.persistence.*;
import lombok.Data;
import lombok.ToString;

import java.util.ArrayList;
import java.util.List;

@Data
@Entity
@ToString(exclude = {"movies", "shows"})
public class Theatre {

    @Id
    Long theatreId;

    String theatreName;

    private Long cityId;

    @ManyToMany(mappedBy = "theatres")
    private List<Movie> movies = new ArrayList<>();

    @OneToMany
    private List<Show> shows = new ArrayList<>();

}
