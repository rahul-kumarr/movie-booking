package org.sapient.controllers;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.sapient.dto.MovieDTO;
import org.sapient.services.MovieService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Tag(name = "Movie Controller", description = "APIs for movie catalog operations")
@RestController
@RequestMapping("/api/v1/movies")
public class MovieController {

    private static final Logger logger = LoggerFactory.getLogger(MovieController.class);

    private final MovieService movieService;

    @Autowired
    public MovieController(MovieService movieService) {
        this.movieService = movieService;
    }

   @GetMapping("/city/{cityId}")
   @Operation(summary = "Get movies by city", description = "Retrieves all movies playing in a specific city")
   @ApiResponse(responseCode = "200", description = "Movies retrieved successfully")
   public ResponseEntity<List<MovieDTO>> getMoviesByCity(@PathVariable Long cityId) {
       logger.info("Request received to fetch movies for city ID: {}", cityId);
       List<MovieDTO> movies = movieService.getMoviesByCity(cityId);
       return ResponseEntity.ok(movies);
   }
}
