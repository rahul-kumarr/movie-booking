package org.sapient.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class CityDTO {
    private Long id;
    private String name;
    @JsonIgnore
    private List<MovieDTO> movies;
    @JsonIgnore
    private List<TheatreDTO> theatres;
}
