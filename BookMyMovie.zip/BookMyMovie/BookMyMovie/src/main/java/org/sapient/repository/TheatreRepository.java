package org.sapient.repository;

import org.sapient.entities.Theatre;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.time.LocalDate;
import java.util.List;

public interface TheatreRepository  extends JpaRepository<Theatre, Long> {

    // Find all theatres by city ID
    List<Theatre> findByCityId(Long cityId);

    @Query(" SELECT DISTINCT t FROM Theatre t JOIN t.movies m JOIN t.shows s " +
            "WHERE t.cityId = :cityId AND m.movieId = :movieId AND s.showDate = :chosenDate ")
    List<Theatre> findByCityIdAndMoviesMovieIdForDate(Long cityId, Long movieId, LocalDate chosenDate);

}
