package org.sapient.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Global exception handler for the ticket booking system
 * Handles all custom exceptions and provides consistent error responses
 */
@ControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

    /**
     * Handler for ResourceNotFoundException
     * Returns 404 NOT_FOUND status
     */
    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<Object> handleResourceNotFoundException(
            ResourceNotFoundException ex, WebRequest request) {

        Map<String, Object> body = createErrorBody(
                HttpStatus.NOT_FOUND.value(),
                "Resource Not Found",
                ex.getMessage());

        return new ResponseEntity<>(body, HttpStatus.NOT_FOUND);
    }

    /**
     * Handler for SeatUnavailableException
     * Returns 409 CONFLICT status
     */
    @ExceptionHandler(SeatUnavailableException.class)
    public ResponseEntity<Object> handleSeatUnavailableException(
            SeatUnavailableException ex, WebRequest request) {

        Map<String, Object> body = createErrorBody(
                HttpStatus.CONFLICT.value(),
                "Seat Unavailable",
                ex.getMessage());

        return new ResponseEntity<>(body, HttpStatus.CONFLICT);
    }

    /**
     * Handler for SeatCanNotBeBookedException
     * Returns 422 UNPROCESSABLE_ENTITY status
     */
    @ExceptionHandler(SeatCanNotBeBookedException.class)
    public ResponseEntity<Object> handleSeatCanNotBeBookedException(
            SeatCanNotBeBookedException ex, WebRequest request) {

        Map<String, Object> body = createErrorBody(
                HttpStatus.UNPROCESSABLE_ENTITY.value(),
                "Seat Booking Failed",
                ex.getMessage());

        return new ResponseEntity<>(body, HttpStatus.UNPROCESSABLE_ENTITY);
    }

    /**
     * Handler for SeatFailedToReleaseException
     * Returns 500 INTERNAL_SERVER_ERROR status
     */
    @ExceptionHandler(SeatFailedToReleaseException.class)
    public ResponseEntity<Object> handleSeatFailedToReleaseException(
            SeatFailedToReleaseException ex, WebRequest request) {

        Map<String, Object> body = createErrorBody(
                HttpStatus.INTERNAL_SERVER_ERROR.value(),
                "Seat Release Failed",
                ex.getMessage());

        return new ResponseEntity<>(body, HttpStatus.INTERNAL_SERVER_ERROR);
    }
    /**
     * Handler for ShowNotFoundException
     * Returns 500 INTERNAL_SERVER_ERROR status
     */
    @ExceptionHandler(ShowNotFoundException.class)
    public ResponseEntity<Object> handleShowNotFoundException(
            ShowNotFoundException ex, WebRequest request) {

        Map<String, Object> body = createErrorBody(
                HttpStatus.INTERNAL_SERVER_ERROR.value(),
                "Show unavailable",
                ex.getMessage());

        return new ResponseEntity<>(body, HttpStatus.INTERNAL_SERVER_ERROR);
    }
    /**
     * Handler for NoTheatreFoundException
     * Returns 500 INTERNAL_SERVER_ERROR status
     */
    @ExceptionHandler(NoTheatreFoundException.class)
    public ResponseEntity<Object> handleNoTheatreFoundException(
            NoTheatreFoundException ex, WebRequest request) {

        Map<String, Object> body = createErrorBody(
                HttpStatus.INTERNAL_SERVER_ERROR.value(),
                "Theatre unavailable",
                ex.getMessage());

        return new ResponseEntity<>(body, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    /**
     * Handler for all other exceptions
     * Returns 500 INTERNAL_SERVER_ERROR status
     */
    @ExceptionHandler(Exception.class)
    public ResponseEntity<Object> handleAllUncaughtException(
            Exception ex, WebRequest request) {

        Map<String, Object> body = createErrorBody(
                HttpStatus.INTERNAL_SERVER_ERROR.value(),
                "Internal Server Error",
                "An unexpected error occurred. Please try again later.");

        // Log the actual exception for debugging purposes
        logger.error("Unhandled exception occurred", ex);

        return new ResponseEntity<>(body, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    /**
     * Helper method to create standardized error response body
     */
    private Map<String, Object> createErrorBody(int status, String error, String message) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("timestamp", LocalDateTime.now().toString());
        body.put("status", status);
        body.put("error", error);
        body.put("message", message);
        return body;
    }
}