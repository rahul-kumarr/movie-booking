package org.sapient.services.impl;

import org.sapient.model.BookingEvent;
import org.sapient.dto.BookingDTO;
import org.sapient.model.BookingRequest;
import org.sapient.entities.Booking;
import org.sapient.entities.Seat;
import org.sapient.entities.Show;
import org.sapient.enums.BookingStatus;
import org.sapient.exception.ResourceNotFoundException;
import org.sapient.repository.BookingRepository;
import org.sapient.repository.ShowRepository;
import org.sapient.services.BookingService;
import org.sapient.services.PaymentService;
import org.sapient.services.SeatService;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Service
public class BookingServiceImpl implements BookingService {

    @Autowired
    SeatService seatService;

    @Autowired
    BookingRepository bookingRepository;

    @Autowired
    ShowRepository showRepository;

    @Autowired
    PaymentService paymentService;

    private static final String BOOKING_CREATED_TOPIC = "booking-created";
    private static final Logger logger = LoggerFactory.getLogger(BookingServiceImpl.class);


    @Override
    public BookingDTO initiateBooking(BookingRequest bookingDto) {

        Show show = showRepository.findById(bookingDto.getShowId())
                .orElseThrow(() -> new ResourceNotFoundException("Show not found with id: " + bookingDto.getShowId()));


        List<Seat> seats = seatService.getSeatsByIds(bookingDto.getSeatNumbers());


        //Lock the seats for some time
        try{
        seatService.lockSeats(show.getShowId(),seats);
        Double totalAmount = paymentService.processPayment(seats);
        Booking savedBooking = createTheBooking(show, totalAmount, bookingDto.getSeatNumbers());

           // Mark seats as booked
           seatService.confirmSeats(show.getShowId(), seats);

           // Publish booking created event to Kafka
           BookingEvent bookingEvent = publishBookingCreatedEvent(savedBooking);
           ModelMapper modelMapper = new ModelMapper();
          return modelMapper.map(bookingEvent, BookingDTO.class);

       }catch (Exception exception){
           logger.info("Exception occurred while booking the seats, rolling back and releasing the seats");
           seatService.releaseSeats(show.getShowId(), seats);
           throw exception;
       }

    }

    private Booking createTheBooking(Show show, Double totalAmount, List<Long> seatNumbers) {

        // Create booking entity
        Booking booking = new Booking();
        booking.setId(generateBookingNumber());
        booking.setShowId(show.getShowId());
        booking.setMovieName(show.getMovie().getMovieName());
        booking.setBookingTime(LocalDateTime.now());
        booking.setBookingStatus(BookingStatus.CONFIRMED);
        booking.setTotalAmount(totalAmount);
        booking.setShowStartTime(show.getShowStartTime());
        booking.setShowDate(show.getShowDate());
        booking.setSeatNumbers(seatNumbers);

        return bookingRepository.save(booking);
    }

    private Double calculateTotalAmount(Show show, List<Long> seatNumbers) {

    return null;

    }

    @Override
    public BookingDTO getBookingById(Long bookingId) {
        return null;
    }


      /**
     * Calculates total amount for the booking with applicable discounts
     * @param show Show entity
     * @param seatCount Number of seats booked
     * @return Total amount after applying discounts
     */
//    private BigDecimal calculateTotalAmount(Show show, int seatCount) {
//        BigDecimal basePrice = show.getSeats().multiply(new BigDecimal(seatCount));
//        return discountService.applyDiscount(show, seatCount, basePrice);
//    }

    /**
     *
     * @return Unique booking number
     */
    private String generateBookingNumber() {
        return "BK" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
    }
//
    /**
     * Publishes booking created event to Kafka
     */
    private BookingEvent publishBookingCreatedEvent(Booking booking) {

        BookingEvent bookingEvent = new BookingEvent();

        bookingEvent.setBookingId(booking.getId());
        bookingEvent.setShowId(booking.getShowId());
        bookingEvent.setBookingStatus(BookingStatus.CONFIRMED);
        bookingEvent.setTotalAmount(booking.getTotalAmount());
        bookingEvent.setSeatNumbers(booking.getSeatNumbers());
        bookingEvent.setMovieName(booking.getMovieName());
        bookingEvent.setBookingTime(booking.getBookingTime());
        bookingEvent.setShowStartTime(booking.getShowStartTime());
        bookingEvent.setShowDate(booking.getShowDate());


        System.out.println("Your show is confirmed ,here are the details "+ bookingEvent );


        /**
         * Below kafkaTemplate will push the event to Kafka which could be
         * sent to User that booking has been done
         */
//        kafkaTemplate.send(BOOKING_CREATED_TOPIC, event);
        return bookingEvent;
    }

    /**
     * Publishes booking cancelled event to Kafka
     */
    private void publishBookingCancelledEvent(Booking booking) {
        BookingEvent event = new BookingEvent();
        event.setBookingId(booking.getId());
        event.setBookingStatus(BookingStatus.CANCELLED);
        event.setShowId(booking.getShowId());
        event.setTotalAmount(booking.getTotalAmount());
        event.setSeatNumbers(booking.getSeatNumbers());

        System.out.println("Your show is cancelled ,here are the details "+ event);

        /**
         * Below kafkaTemplate will push the event to Kafka which could be
         * sent to User that booking has been done
         */
//        kafkaTemplate.send(BOOKING_CREATED_TOPIC, event);
    }
}
