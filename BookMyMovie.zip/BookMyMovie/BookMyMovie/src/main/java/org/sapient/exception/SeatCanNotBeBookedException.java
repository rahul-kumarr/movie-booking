package org.sapient.exception;

public class SeatCanNotBeBookedException extends RuntimeException {
    public SeatCanNotBeBookedException(String message){
        super(message);
    }
}
