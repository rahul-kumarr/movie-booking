package org.sapient.entities;


import jakarta.persistence.*;
import lombok.Data;
import org.sapient.enums.SeatCategory;
import org.sapient.enums.SeatStatus;


@Data
@Entity
//@ToString(exclude = { "screen"})
public class Seat {

    @Id
    Long seatId;

    int seatRow;

    Boolean isBooked=false;

    @Enumerated(EnumType.STRING)
    SeatStatus seatStatus;

    @Enumerated(EnumType.STRING)
    SeatCategory seatCategory;

    private double price;

//    @ManyToOne
//    private Show show;

}
