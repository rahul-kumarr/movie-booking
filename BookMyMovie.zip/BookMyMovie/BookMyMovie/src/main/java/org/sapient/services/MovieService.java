package org.sapient.services;

import org.sapient.dto.MovieDTO;

import java.util.List;

public interface MovieService {
    List<MovieDTO> getMoviesByCity(Long cityId);
}
