package org.sapient.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class MovieDTO {

        Long movieId;
        String movieName;
        int movieDurationInMinutes;

    public MovieDTO(Long movieId, String movieName, int movieDurationInMinutes) {
        this.movieId = movieId;
        this.movieName = movieName;
        this.movieDurationInMinutes = movieDurationInMinutes;
    }

    public MovieDTO(){}

}
