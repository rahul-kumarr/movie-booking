package org.sapient.services;


import org.sapient.dto.TheatreDTO;

import java.time.LocalDate;
import java.util.List;

public interface TheatreService {

    List<TheatreDTO> getAllTheatres(Long cityId, Long movieId, LocalDate date);

    List<TheatreDTO> getAllTheatresInACity(Long cityId);

    TheatreDTO getTheTheatreDetail(Long theatreId);
}
