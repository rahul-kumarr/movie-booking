package org.sapient.services;

import org.sapient.dto.BookingDTO;
import org.sapient.model.BookingRequest;

public interface BookingService {

    BookingDTO initiateBooking(BookingRequest bookingDTO);
    BookingDTO getBookingById(Long bookingId);

}
