package org.sapient.controllers;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.sapient.dto.BookingDTO;
import org.sapient.model.BookingRequest;
import org.sapient.services.BookingService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/bookings")
@Tag(name = "Booking Controller", description = "APIs for booking operations")
public class BookingController {

    private static final Logger logger = LoggerFactory.getLogger(BookingController.class);

    private final BookingService bookingService;

    @Autowired
    public BookingController(BookingService bookingService) {
        this.bookingService = bookingService;
    }

    @PostMapping
    @Operation(summary = "Book tickets", description = "Books tickets for a show")
    @ApiResponse(responseCode = "201", description = "Booking created successfully")
    public ResponseEntity<BookingDTO> bookTickets(
            @Valid @RequestBody BookingRequest bookingRequest) {
        logger.info("Request received to book tickets for show ID: {}",
                bookingRequest.getShowId());
        BookingDTO bookingResponse = bookingService.initiateBooking(bookingRequest);
        logger.info("Tickets booked successfully for show ID: {}",
                bookingRequest.getShowId());
        return new ResponseEntity<>(bookingResponse, HttpStatus.CREATED);
    }
}
