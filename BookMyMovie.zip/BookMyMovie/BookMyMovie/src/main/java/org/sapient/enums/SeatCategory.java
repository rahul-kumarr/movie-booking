package org.sapient.enums;

public enum SeatCategory {
    SILVER,
    GOLD,
    PLATINUM;
}
