package org.sapient.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
//@Builder
public class TheatreDTO {
    private Long theatreId;
    private String theatreName;
    private Long cityId;
    private List<ShowDTO> shows;
}
