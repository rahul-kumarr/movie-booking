package org.sapient.dto;

import lombok.Data;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Data
public class ShowDTO {

    Long showId;

    private Long movieId;

    String movieName;

    private String showStartTime;

    private LocalDate showDate;

//    private List<Integer> bookedSeatIds = new ArrayList<>();

    private List<SeatDTO> seats = new ArrayList<>();

}
