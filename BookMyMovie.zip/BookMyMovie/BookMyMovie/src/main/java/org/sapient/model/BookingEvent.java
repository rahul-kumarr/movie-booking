package org.sapient.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.sapient.enums.BookingStatus;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@ToString
@Setter
@Getter
public class BookingEvent implements Serializable {
    public static final Long serialVersionUuid = 1L;

    String bookingId;
    Long showId;
    String movieName;
    String showStartTime;
    LocalDate showDate;
    LocalDateTime bookingTime;
    BookingStatus bookingStatus;
    List<Long> seatNumbers;
    Double totalAmount;

}
