package org.sapient.services;

import org.sapient.entities.Seat;
import org.springframework.cache.annotation.Cacheable;

import java.util.List;

public interface SeatService {
    @Cacheable("seats")
    List<Seat> getSeatsByIds(List<Long> ids);

    void lockSeats(Long showId, List<Seat> seats);
    void confirmSeats(Long showId, List<Seat> seats);
    void releaseSeats(Long showId, List<Seat> seats);


}
