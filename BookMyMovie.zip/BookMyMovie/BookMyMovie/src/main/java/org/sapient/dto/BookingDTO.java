package org.sapient.dto;

import lombok.Data;
import org.sapient.enums.BookingStatus;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Data
public class BookingDTO {

    String bookingId;
    Long showId;
    String movieName;
    String showStartTime;
    LocalDate showDate;
    BookingStatus bookingStatus;
    List<Long> seatNumbers;
    Double totalAmount;
    LocalDateTime bookingTime;

}
