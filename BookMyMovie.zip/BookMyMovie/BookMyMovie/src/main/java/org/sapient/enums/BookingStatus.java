package org.sapient.enums;

public enum BookingStatus {
    CONFIRMED,CANCELLED
}
