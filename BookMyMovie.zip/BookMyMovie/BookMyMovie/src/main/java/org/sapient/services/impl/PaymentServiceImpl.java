package org.sapient.services.impl;

import org.sapient.entities.Seat;
import org.sapient.services.PaymentService;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

@Service
public class PaymentServiceImpl implements PaymentService {

    @Override
    public Double processPayment(List<Seat> seatList) {
        Double totalAmount = calculateTotalAmount(seatList);
        System.out.println("💳 Processing payment of ₹" + totalAmount + "...");
        // Simulate success
        return totalAmount;
    }

    private Double calculateTotalAmount(List<Seat> seats) {
        return round(seats.stream()
                .mapToDouble(Seat::getPrice)
                .sum());
    }

    private static double round(double value) {
        return new BigDecimal(value).setScale(2, RoundingMode.HALF_UP).doubleValue();
    }
}
