package org.sapient.entities;

import jakarta.persistence.*;
import lombok.Data;
import lombok.ToString;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Data
@Entity
@ToString
public class Show {

    @Id
    Long showId;

    @ManyToOne
    private Movie movie;

    private String showStartTime;

    private LocalDate showDate;

    @OneToMany
    private List<Seat> seats = new ArrayList<>();

}
