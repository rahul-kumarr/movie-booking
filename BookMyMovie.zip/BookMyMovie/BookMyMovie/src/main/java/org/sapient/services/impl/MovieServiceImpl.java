package org.sapient.services.impl;

import org.sapient.dto.MovieDTO;
import org.sapient.entities.City;
import org.sapient.repository.CityRepository;
import org.sapient.services.MovieService;
import org.sapient.util.MapperUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class MovieServiceImpl implements MovieService {

    @Autowired
    private CityRepository cityRepository;

    @Override
    @Transactional(readOnly = true)
    @Cacheable(value = "moviesByCity", key = "#cityId")
    public List<MovieDTO> getMoviesByCity(Long cityId) {
        Optional<City> cityById = cityRepository.findById(cityId);
        return MapperUtil.getMovieDTOS(cityById);
    }

}
