package org.sapient.exception;

public class NoTheatreFoundException extends RuntimeException {
    public NoTheatreFoundException(String message){
        super(message);
    }
}
