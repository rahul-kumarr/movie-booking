package org.sapient.exception;

public class SeatFailedToReleaseException extends RuntimeException {
    public SeatFailedToReleaseException(String message){
        super(message);
    }
}
