package org.sapient.enums;

public enum SeatStatus {
    AVAILABLE,BOOKED,LOCKED
}
