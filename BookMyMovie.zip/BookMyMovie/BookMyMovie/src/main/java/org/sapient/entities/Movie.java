package org.sapient.entities;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Data;
import lombok.ToString;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Data
@Entity
@ToString(exclude = {"cities", "theatres"})
public class Movie {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long movieId;
    String movieName;
    int movieDurationInMinutes;

    @JsonIgnore
    @ManyToMany(mappedBy = "movies")
    private Set<City> cities = new HashSet<>();

    @ManyToMany
    @JoinTable(
            name = "movie_theatre",
            joinColumns = @JoinColumn(name = "movie_id"),
            inverseJoinColumns = @JoinColumn(name = "theatre_id")
    )
    private List<Theatre> theatres = new ArrayList<>();

    //other details like Genere, Language etc.
}
