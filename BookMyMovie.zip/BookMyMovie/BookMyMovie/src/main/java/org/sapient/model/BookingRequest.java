package org.sapient.model;

import lombok.Data;

import java.util.List;

@Data
public class BookingRequest {
    Long showId;
    List<Long> seatNumbers;
}
