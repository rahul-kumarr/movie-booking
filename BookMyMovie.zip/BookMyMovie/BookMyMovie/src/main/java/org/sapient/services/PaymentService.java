package org.sapient.services;

import org.sapient.entities.Seat;

import java.util.List;

public interface PaymentService {

    Double processPayment(List<Seat> seatList);
}
