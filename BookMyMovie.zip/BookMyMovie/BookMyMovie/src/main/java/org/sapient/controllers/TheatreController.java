package org.sapient.controllers;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.sapient.dto.TheatreDTO;
import org.sapient.services.TheatreService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

import static org.sapient.services.impl.TheatreServiceImpl.validateSelectedDate;

@RestController
@RequestMapping("/api/v1/theatres")
@Tag(name = "Theatre Controller", description = "APIs for theatre management operations")
public class TheatreController {

    private static final Logger logger = LoggerFactory.getLogger(TheatreController.class);

    private final TheatreService theatreService;

    @Autowired
    public TheatreController(TheatreService theatreService) {
        this.theatreService = theatreService;
    }


    @GetMapping("/city/{cityId}/movies/{movieId}")
    @Operation(summary = "Get theatres by city and movie", description = "Retrieves all theatres in a specific city showing the movie")
    @ApiResponse(responseCode = "200", description = "Theatres retrieved successfully")
    public ResponseEntity<List<TheatreDTO>> getTheatresByCity(@PathVariable Long cityId,
                                                              @PathVariable Long movieId,
                                                              @RequestParam(value = "chosenDate")
                                                                  @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate chosenDate ) {
        logger.info("Request received to fetch theatres for city ID, and movie ID: {} {}", cityId,movieId);
        chosenDate = validateSelectedDate(chosenDate);
        List<TheatreDTO> theatres = theatreService.getAllTheatres(cityId,movieId,chosenDate);
        return ResponseEntity.ok(theatres);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get theatre by ID", description = "Retrieves theatre details by its ID")
    @ApiResponse(responseCode = "200", description = "Theatre retrieved successfully")
    @ApiResponse(responseCode = "404", description = "Theatre not found")
    public ResponseEntity<TheatreDTO> getTheatreById(@PathVariable Long id) {
        logger.info("Request received to fetch theatre with ID: {}", id);
        return ResponseEntity.ok(theatreService.getTheTheatreDetail(id));
    }
}