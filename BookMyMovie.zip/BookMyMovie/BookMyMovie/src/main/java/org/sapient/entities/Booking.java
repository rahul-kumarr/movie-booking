package org.sapient.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import lombok.Data;
import org.sapient.enums.BookingStatus;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Data
public class Booking {

    @Id
    private String id;

    private Long showId;

    private String movieName;

    private String showStartTime;

    private LocalDate showDate;

    private Double totalAmount;

    private List<Long> seatNumbers;

    @Enumerated(EnumType.STRING)
    private BookingStatus bookingStatus;

    private LocalDateTime bookingTime;



}
