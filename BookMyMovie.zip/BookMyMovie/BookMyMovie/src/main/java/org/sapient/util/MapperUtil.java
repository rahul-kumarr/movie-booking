package org.sapient.util;

import org.sapient.dto.MovieDTO;
import org.sapient.entities.City;
import org.sapient.exception.ResourceNotFoundException;
import org.springframework.beans.BeanUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class MapperUtil {

    public static List<MovieDTO> getMovieDTOS(Optional<City> cityById) {
        List<MovieDTO> movieDTOs = new ArrayList<>();
        if(cityById.isEmpty()){
            throw new ResourceNotFoundException("No City or Movie found with for selected city id: " );
        }
        cityById.ifPresent(city ->{
            city.getMovies().forEach(movie ->{
                MovieDTO movieDTO = new MovieDTO();
                BeanUtils.copyProperties(movie, movieDTO);
                movieDTOs.add(movieDTO);
            });
        });
        return movieDTOs;
    }

}
