package org.sapient.services.impl;

import org.sapient.entities.Seat;
import org.sapient.enums.SeatStatus;
import org.sapient.exception.SeatCanNotBeBookedException;
import org.sapient.exception.SeatFailedToReleaseException;
import org.sapient.exception.SeatUnavailableException;
import org.sapient.model.SeatLock;
import org.sapient.repository.SeatRepository;
import org.sapient.services.SeatService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class SeatServiceImpl implements SeatService {

    // In-memory cache for seat locks to minimize database contention
    // mimicking the distributed REDIS with key format: "showId:seatId"
    private final Map<String, SeatLock> seatLocks = new ConcurrentHashMap<>();

    private static final Logger logger = LoggerFactory.getLogger(SeatServiceImpl.class);


    @Autowired
    SeatRepository seatRepository;

    @Override
    @Transactional(readOnly = true)
    @Cacheable(value = "getSeatsByIds", key = "#ids")
    public List<Seat> getSeatsByIds(List<Long> ids) {
        logger.info("Fetching the seats");
        List<Seat> a= seatRepository.findBySeatIdIn(ids);
        logger.info("fetched seats from DB ");
        return a;
    }

    @Override
    @Transactional
    public void lockSeats(Long showId, List<Seat> allSeats) {
        String sessionId = generateBookingSessionId();

        try {
            // First, perform an optimistic read to check if all seats are available
            for (Seat seat : allSeats) {
                if (!SeatStatus.AVAILABLE.equals(seat.getSeatStatus())) {
                    throw new SeatUnavailableException("Seat " + seat.getSeatId() + " is not available");
                }

                String lockKey = getLockKey(showId, seat.getSeatId());

                // Check if the seat is already locked
                SeatLock existingLock = seatLocks.get(lockKey);
                if (existingLock != null && !existingLock.isExpired()) {
                    throw new SeatUnavailableException("Seat " + seat.getSeatId() + " is already locked by another User");
                }
            }

            // If all seats are available, lock them
            for (Seat seat : allSeats) {
                String lockKey = getLockKey(showId, seat.getSeatId());

                // Attempt to acquire lock
                SeatLock newLock = new SeatLock(sessionId);
                SeatLock existingLock = seatLocks.putIfAbsent(lockKey, newLock);

                // If lock exists and is not expired, someone else got it first
                if (existingLock != null && !existingLock.isExpired()) {
                    // Rollback any acquired locks
                    releaseSessionLocks(sessionId, showId, allSeats);
                    throw new SeatUnavailableException("Seat " + seat.getSeatId() + " was locked by another User");
                }

                // Update the seat status to LOCKED
                seat.setSeatStatus(SeatStatus.LOCKED);
            }
            // Persist all locked seats to the database
            seatRepository.saveAllAndFlush(allSeats);
        } catch (Exception ex) {
            // Release all locks on failure
            releaseSessionLocks(sessionId, showId, allSeats);
            throw new SeatUnavailableException("Seats is/are Unavailable: " + ex.getMessage());
        }
    }



    @Override
    @Transactional
    public void confirmSeats(Long showId, List<Seat> allSeats) {
        try {
            for (Seat seat : allSeats) {
                String lockKey = getLockKey(showId, seat.getSeatId());

                // Verify that we still own the lock before confirming
                SeatLock lock = seatLocks.get(lockKey);
                if (lock == null || lock.isExpired()) {
                    throw new SeatCanNotBeBookedException("Lock for seat " + seat.getSeatId() + " has expired");
                }

                // Update seat status to BOOKED
                seat.setIsBooked(true);
                seat.setSeatStatus(SeatStatus.BOOKED);

                // Remove the lock since the seat is now booked
                seatLocks.remove(lockKey);
            }

            // Save all booked seats
            seatRepository.saveAllAndFlush(allSeats);
        } catch (Exception ex) {
            throw new SeatCanNotBeBookedException("Failed to confirm seats: " + ex.getMessage());
        }
    }

    @Override
    @Transactional
    public void releaseSeats(Long showId, List<Seat> allSeats) {
        try {
            for (Seat seat : allSeats) {
                String lockKey = getLockKey(showId, seat.getSeatId());

                // Update seat status back to AVAILABLE
                if(SeatStatus.LOCKED.equals(seat.getSeatStatus())){
                    seat.setSeatStatus(SeatStatus.AVAILABLE);
                    // Remove the lock
                    seatLocks.remove(lockKey);
                }
            }
            // Save all released seats
            seatRepository.saveAllAndFlush(allSeats);
        } catch (Exception ex) {
            throw new SeatFailedToReleaseException("Failed to release seats: " + ex.getMessage());
        }
    }


    /**
     * Generates a unique lock key for a seat in a show
     */
    private String getLockKey(Long showId, Long seatId) {
        return showId + ":" + seatId;
    }

    /**
     * Generates a unique booking session ID
     */
    private String generateBookingSessionId() {
        return "session-" + System.currentTimeMillis();
    }
    /**
     * Helper method to release all locks for a session
     */
    private void releaseSessionLocks(String sessionId, Long showId, List<Seat> seats) {
        for (Seat seat : seats) {
            String lockKey = getLockKey(showId, seat.getSeatId());
            SeatLock lock = seatLocks.get(lockKey);

            // Only remove the lock if it belongs to this session
            if (lock != null && Objects.equals(lock.getLockOwner(), sessionId)) {
                seatLocks.remove(lockKey);
            }
        }
    }

}