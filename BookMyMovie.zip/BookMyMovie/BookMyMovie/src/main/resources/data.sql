-- Insert Cities
INSERT INTO city (id, name) VALUES (1, 'Delhi');
INSERT INTO city (id, name) VALUES (2, 'Mumbai');

-- Insert Movies
INSERT INTO movie (movie_id, movie_name, movie_duration_in_minutes) VALUES (1, 'Raid', 125);
INSERT INTO movie (movie_id, movie_name, movie_duration_in_minutes) VALUES (2, 'KGF', 155);
INSERT INTO movie (movie_id, movie_name, movie_duration_in_minutes) VALUES (3, 'Interstellar', 169);

-- Insert Theatres
-- Delhi Theatres
INSERT INTO theatre (theatre_id, theatre_name, city_id) VALUES (1, 'INOX', 1);
INSERT INTO theatre (theatre_id, theatre_name, city_id) VALUES (2, 'PVR', 1);
INSERT INTO theatre (theatre_id, theatre_name, city_id) VALUES (3, 'IMAX', 1);

-- Mumbai Theatres
INSERT INTO theatre (theatre_id, theatre_name, city_id) VALUES (4, 'Cinepolis', 2);
INSERT INTO theatre (theatre_id, theatre_name, city_id) VALUES (5, 'INOX', 2);

-- Connect Cities and Movies (Many-to-Many)
INSERT INTO city_movie (city_id, movie_id) VALUES (1, 1); -- Delhi - Raid
INSERT INTO city_movie (city_id, movie_id) VALUES (1, 2); -- Delhi - KGF
INSERT INTO city_movie (city_id, movie_id) VALUES (1, 3); -- Delhi - Interstellar
INSERT INTO city_movie (city_id, movie_id) VALUES (2, 1); -- Mumbai - Raid
INSERT INTO city_movie (city_id, movie_id) VALUES (2, 2); -- Mumbai - KGF
INSERT INTO city_movie (city_id, movie_id) VALUES (2, 3); -- Mumbai - Interstellar

-- Connect Movies and Theatres (Many-to-Many)
-- Delhi Theatres
INSERT INTO movie_theatre (movie_id, theatre_id) VALUES (1, 1); -- Raid - INOX Delhi
INSERT INTO movie_theatre (movie_id, theatre_id) VALUES (2, 1); -- KGF - INOX Delhi
INSERT INTO movie_theatre (movie_id, theatre_id) VALUES (3, 1); -- Interstellar - INOX Delhi
INSERT INTO movie_theatre (movie_id, theatre_id) VALUES (1, 2); -- Raid - PVR Delhi
INSERT INTO movie_theatre (movie_id, theatre_id) VALUES (2, 2); -- KGF - PVR Delhi
INSERT INTO movie_theatre (movie_id, theatre_id) VALUES (1, 3); -- Raid - IMAX Delhi
INSERT INTO movie_theatre (movie_id, theatre_id) VALUES (3, 3); -- Interstellar - IMAX Delhi

-- Mumbai Theatres
INSERT INTO movie_theatre (movie_id, theatre_id) VALUES (1, 4); -- Raid - Cinepolis Mumbai
INSERT INTO movie_theatre (movie_id, theatre_id) VALUES (3, 4); -- Interstellar - Cinepolis Mumbai
INSERT INTO movie_theatre (movie_id, theatre_id) VALUES (2, 5); -- KGF - INOX Mumbai
INSERT INTO movie_theatre (movie_id, theatre_id) VALUES (3, 5); -- Interstellar - INOX Mumbai

-- Insert Shows with show_date using CURRENT_DATE function and future dates
-- Shows for today
-- Delhi - INOX Theatre (ID: 1)
INSERT INTO show (show_id, movie_movie_id, show_start_time, show_date) VALUES (1, 1, '10:00 AM', CURRENT_DATE); -- Raid - 10 AM
INSERT INTO show (show_id, movie_movie_id, show_start_time, show_date) VALUES (2, 1, '15:00 PM', CURRENT_DATE); -- Raid - 3 PM
INSERT INTO show (show_id, movie_movie_id, show_start_time, show_date) VALUES (3, 2, '10:00 AM', CURRENT_DATE); -- KGF - 10 AM
INSERT INTO show (show_id, movie_movie_id, show_start_time, show_date) VALUES (4, 2, '15:00 PM', CURRENT_DATE); -- KGF - 3 PM

-- Shows for tomorrow
INSERT INTO show (show_id, movie_movie_id, show_start_time, show_date) VALUES (5, 3, '10:00 AM', DATEADD('DAY', 1, CURRENT_DATE)); -- Interstellar - 10 AM
INSERT INTO show (show_id, movie_movie_id, show_start_time, show_date) VALUES (6, 3, '15:00 PM', DATEADD('DAY', 1, CURRENT_DATE)); -- Interstellar - 3 PM

-- Delhi - PVR Theatre (ID: 2)
-- Shows for today
INSERT INTO show (show_id, movie_movie_id, show_start_time, show_date) VALUES (7, 1, '10:00 AM', CURRENT_DATE); -- Raid - 10 AM
INSERT INTO show (show_id, movie_movie_id, show_start_time, show_date) VALUES (8, 1, '15:00 PM', CURRENT_DATE); -- Raid - 3 PM

-- Shows for tomorrow
INSERT INTO show (show_id, movie_movie_id, show_start_time, show_date) VALUES (9, 2, '10:00 AM', DATEADD('DAY', 1, CURRENT_DATE)); -- KGF - 10 AM
INSERT INTO show (show_id, movie_movie_id, show_start_time, show_date) VALUES (10, 2, '15:00 PM', DATEADD('DAY', 1, CURRENT_DATE)); -- KGF - 3 PM

-- Delhi - IMAX Theatre (ID: 3)
-- Shows for today
INSERT INTO show (show_id, movie_movie_id, show_start_time, show_date) VALUES (11, 1, '10:00 AM', CURRENT_DATE); -- Raid - 10 AM
INSERT INTO show (show_id, movie_movie_id, show_start_time, show_date) VALUES (12, 1, '15:00 PM', CURRENT_DATE); -- Raid - 3 PM

-- Shows for tomorrow
INSERT INTO show (show_id, movie_movie_id, show_start_time, show_date) VALUES (13, 3, '10:00 AM', DATEADD('DAY', 1, CURRENT_DATE)); -- Interstellar - 10 AM
INSERT INTO show (show_id, movie_movie_id, show_start_time, show_date) VALUES (14, 3, '15:00 PM', DATEADD('DAY', 1, CURRENT_DATE)); -- Interstellar - 3 PM

-- Mumbai - Cinepolis Theatre (ID: 4)
-- Shows for today
INSERT INTO show (show_id, movie_movie_id, show_start_time, show_date) VALUES (15, 1, '10:00 AM', CURRENT_DATE); -- Raid - 10 AM
INSERT INTO show (show_id, movie_movie_id, show_start_time, show_date) VALUES (16, 1, '15:00 PM', CURRENT_DATE); -- Raid - 3 PM

-- Shows for day after tomorrow
INSERT INTO show (show_id, movie_movie_id, show_start_time, show_date) VALUES (17, 3, '10:00 AM', DATEADD('DAY', 2, CURRENT_DATE)); -- Interstellar - 10 AM
INSERT INTO show (show_id, movie_movie_id, show_start_time, show_date) VALUES (18, 3, '15:00 PM', DATEADD('DAY', 2, CURRENT_DATE)); -- Interstellar - 3 PM

-- Mumbai - INOX Theatre (ID: 5)
-- Shows for today
INSERT INTO show (show_id, movie_movie_id, show_start_time, show_date) VALUES (19, 2, '10:00 AM', CURRENT_DATE); -- KGF - 10 AM
INSERT INTO show (show_id, movie_movie_id, show_start_time, show_date) VALUES (20, 2, '15:00 PM', CURRENT_DATE); -- KGF - 3 PM

-- Shows for day after tomorrow
INSERT INTO show (show_id, movie_movie_id, show_start_time, show_date) VALUES (21, 3, '10:00 AM', DATEADD('DAY', 2, CURRENT_DATE)); -- Interstellar - 10 AM
INSERT INTO show (show_id, movie_movie_id, show_start_time, show_date) VALUES (22, 3, '15:00 PM', DATEADD('DAY', 2, CURRENT_DATE)); -- Interstellar - 3 PM
-- Connect Shows to Theatres
-- Delhi - INOX Theatre (ID: 1)
INSERT INTO theatre_shows (theatre_theatre_id, shows_show_id) VALUES (1, 1);
INSERT INTO theatre_shows (theatre_theatre_id, shows_show_id) VALUES (1, 2);
INSERT INTO theatre_shows (theatre_theatre_id, shows_show_id) VALUES (1, 3);
INSERT INTO theatre_shows (theatre_theatre_id, shows_show_id) VALUES (1, 4);
INSERT INTO theatre_shows (theatre_theatre_id, shows_show_id) VALUES (1, 5);
INSERT INTO theatre_shows (theatre_theatre_id, shows_show_id) VALUES (1, 6);

-- Delhi - PVR Theatre (ID: 2)
INSERT INTO theatre_shows (theatre_theatre_id, shows_show_id) VALUES (2, 7);
INSERT INTO theatre_shows (theatre_theatre_id, shows_show_id) VALUES (2, 8);
INSERT INTO theatre_shows (theatre_theatre_id, shows_show_id) VALUES (2, 9);
INSERT INTO theatre_shows (theatre_theatre_id, shows_show_id) VALUES (2, 10);

-- Delhi - IMAX Theatre (ID: 3)
INSERT INTO theatre_shows (theatre_theatre_id, shows_show_id) VALUES (3, 11);
INSERT INTO theatre_shows (theatre_theatre_id, shows_show_id) VALUES (3, 12);
INSERT INTO theatre_shows (theatre_theatre_id, shows_show_id) VALUES (3, 13);
INSERT INTO theatre_shows (theatre_theatre_id, shows_show_id) VALUES (3, 14);

-- Mumbai - Cinepolis Theatre (ID: 4)
INSERT INTO theatre_shows (theatre_theatre_id, shows_show_id) VALUES (4, 15);
INSERT INTO theatre_shows (theatre_theatre_id, shows_show_id) VALUES (4, 16);
INSERT INTO theatre_shows (theatre_theatre_id, shows_show_id) VALUES (4, 17);
INSERT INTO theatre_shows (theatre_theatre_id, shows_show_id) VALUES (4, 18);

-- Mumbai - INOX Theatre (ID: 5)
INSERT INTO theatre_shows (theatre_theatre_id, shows_show_id) VALUES (5, 19);
INSERT INTO theatre_shows (theatre_theatre_id, shows_show_id) VALUES (5, 20);
INSERT INTO theatre_shows (theatre_theatre_id, shows_show_id) VALUES (5, 21);
INSERT INTO theatre_shows (theatre_theatre_id, shows_show_id) VALUES (5, 22);

-- Insert Seats for each Show
-- Function to create seats for a show with different categories
-- Seat IDs are created with a pattern: (show_id * 1000) + seat_number

-- Delhi - INOX Theatre - Show 1 (Raid - 10 AM)
-- Platinum Seats (5 seats)
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (1001, 1, false, 'AVAILABLE', 'PLATINUM', 450.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (1002, 1, false, 'AVAILABLE', 'PLATINUM', 450.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (1003, 1, false, 'AVAILABLE', 'PLATINUM', 450.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (1004, 1, false, 'AVAILABLE', 'PLATINUM', 450.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (1005, 1, false, 'AVAILABLE', 'PLATINUM', 450.00);

-- Gold Seats (7 seats)
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (1006, 2, false, 'AVAILABLE', 'GOLD', 350.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (1007, 2, false, 'AVAILABLE', 'GOLD', 350.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (1008, 2, false, 'AVAILABLE', 'GOLD', 350.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (1009, 2, false, 'AVAILABLE', 'GOLD', 350.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (1010, 2, false, 'AVAILABLE', 'GOLD', 350.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (1011, 2, false, 'AVAILABLE', 'GOLD', 350.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (1012, 2, false, 'AVAILABLE', 'GOLD', 350.00);

-- Silver Seats (6 seats)
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (1013, 3, false, 'AVAILABLE', 'SILVER', 250.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (1014, 3, false, 'AVAILABLE', 'SILVER', 250.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (1015, 3, false, 'AVAILABLE', 'SILVER', 250.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (1016, 3, false, 'AVAILABLE', 'SILVER', 250.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (1017, 3, false, 'AVAILABLE', 'SILVER', 250.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (1018, 3, false, 'AVAILABLE', 'SILVER', 250.00);

-- Delhi - INOX Theatre - Show 2 (Raid - 3 PM)
-- Platinum Seats (5 seats)
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (2001, 1, false, 'AVAILABLE', 'PLATINUM', 450.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (2002, 1, false, 'AVAILABLE', 'PLATINUM', 450.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (2003, 1, false, 'AVAILABLE', 'PLATINUM', 450.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (2004, 1, false, 'AVAILABLE', 'PLATINUM', 450.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (2005, 1, false, 'AVAILABLE', 'PLATINUM', 450.00);

-- Gold Seats (7 seats)
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (2006, 2, false, 'AVAILABLE', 'GOLD', 350.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (2007, 2, false, 'AVAILABLE', 'GOLD', 350.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (2008, 2, false, 'AVAILABLE', 'GOLD', 350.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (2009, 2, false, 'AVAILABLE', 'GOLD', 350.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (2010, 2, false, 'AVAILABLE', 'GOLD', 350.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (2011, 2, false, 'AVAILABLE', 'GOLD', 350.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (2012, 2, false, 'AVAILABLE', 'GOLD', 350.00);

-- Silver Seats (6 seats)
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (2013, 3, false, 'AVAILABLE', 'SILVER', 250.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (2014, 3, false, 'AVAILABLE', 'SILVER', 250.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (2015, 3, false, 'AVAILABLE', 'SILVER', 250.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (2016, 3, false, 'AVAILABLE', 'SILVER', 250.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (2017, 3, false, 'AVAILABLE', 'SILVER', 250.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (2018, 3, false, 'AVAILABLE', 'SILVER', 250.00);

-- Associate Seats with Shows
-- Show 1 (Raid - 10 AM at INOX Delhi)
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (1, 1001);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (1, 1002);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (1, 1003);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (1, 1004);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (1, 1005);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (1, 1006);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (1, 1007);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (1, 1008);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (1, 1009);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (1, 1010);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (1, 1011);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (1, 1012);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (1, 1013);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (1, 1014);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (1, 1015);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (1, 1016);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (1, 1017);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (1, 1018);

-- Show 2 (Raid - 3 PM at INOX Delhi)
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (2, 2001);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (2, 2002);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (2, 2003);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (2, 2004);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (2, 2005);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (2, 2006);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (2, 2007);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (2, 2008);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (2, 2009);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (2, 2010);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (2, 2011);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (2, 2012);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (2, 2013);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (2, 2014);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (2, 2015);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (2, 2016);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (2, 2017);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (2, 2018);

-- Create more seats for remaining shows
-- Show 3 (KGF - 10 AM at INOX Delhi)
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (3001, 1, false, 'AVAILABLE', 'PLATINUM', 500.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (3002, 1, false, 'AVAILABLE', 'PLATINUM', 500.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (3003, 1, false, 'AVAILABLE', 'PLATINUM', 500.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (3004, 1, false, 'AVAILABLE', 'PLATINUM', 500.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (3005, 2, false, 'AVAILABLE', 'GOLD', 400.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (3006, 2, false, 'AVAILABLE', 'GOLD', 400.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (3007, 2, false, 'AVAILABLE', 'GOLD', 400.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (3008, 2, false, 'AVAILABLE', 'GOLD', 400.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (3009, 2, false, 'AVAILABLE', 'GOLD', 400.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (3010, 3, false, 'AVAILABLE', 'SILVER', 300.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (3011, 3, false, 'AVAILABLE', 'SILVER', 300.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (3012, 3, false, 'AVAILABLE', 'SILVER', 300.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (3013, 3, false, 'AVAILABLE', 'SILVER', 300.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (3014, 3, false, 'AVAILABLE', 'SILVER', 300.00);

-- Associate Seats with Show 3
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (3, 3001);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (3, 3002);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (3, 3003);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (3, 3004);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (3, 3005);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (3, 3006);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (3, 3007);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (3, 3008);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (3, 3009);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (3, 3010);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (3, 3011);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (3, 3012);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (3, 3013);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (3, 3014);

-- Show 4 (KGF - 3 PM at INOX Delhi)
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (4001, 1, false, 'AVAILABLE', 'PLATINUM', 500.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (4002, 1, false, 'AVAILABLE', 'PLATINUM', 500.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (4003, 1, false, 'AVAILABLE', 'PLATINUM', 500.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (4004, 1, false, 'AVAILABLE', 'PLATINUM', 500.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (4005, 2, false, 'AVAILABLE', 'GOLD', 400.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (4006, 2, false, 'AVAILABLE', 'GOLD', 400.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (4007, 2, false, 'AVAILABLE', 'GOLD', 400.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (4008, 2, false, 'AVAILABLE', 'GOLD', 400.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (4009, 2, false, 'AVAILABLE', 'GOLD', 400.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (4010, 3, false, 'AVAILABLE', 'SILVER', 300.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (4011, 3, false, 'AVAILABLE', 'SILVER', 300.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (4012, 3, false, 'AVAILABLE', 'SILVER', 300.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (4013, 3, false, 'AVAILABLE', 'SILVER', 300.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (4014, 3, false, 'AVAILABLE', 'SILVER', 300.00);

-- Associate Seats with Show 4
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (4, 4001);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (4, 4002);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (4, 4003);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (4, 4004);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (4, 4005);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (4, 4006);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (4, 4007);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (4, 4008);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (4, 4009);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (4, 4010);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (4, 4011);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (4, 4012);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (4, 4013);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (4, 4014);

-- Show 5 (Interstellar - 10 AM at INOX Delhi)
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (5001, 1, false, 'AVAILABLE', 'PLATINUM', 550.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (5002, 1, false, 'AVAILABLE', 'PLATINUM', 550.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (5003, 1, false, 'AVAILABLE', 'PLATINUM', 550.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (5004, 1, false, 'AVAILABLE', 'PLATINUM', 550.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (5005, 1, false, 'AVAILABLE', 'PLATINUM', 550.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (5006, 1, false, 'AVAILABLE', 'PLATINUM', 550.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (5007, 2, false, 'AVAILABLE', 'GOLD', 450.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (5008, 2, false, 'AVAILABLE', 'GOLD', 450.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (5009, 2, false, 'AVAILABLE', 'GOLD', 450.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (5010, 2, false, 'AVAILABLE', 'GOLD', 450.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (5011, 3, false, 'AVAILABLE', 'SILVER', 350.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (5012, 3, false, 'AVAILABLE', 'SILVER', 350.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (5013, 3, false, 'AVAILABLE', 'SILVER', 350.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (5014, 3, false, 'AVAILABLE', 'SILVER', 350.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (5015, 3, false, 'AVAILABLE', 'SILVER', 350.00);

-- Associate Seats with Show 5
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (5, 5001);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (5, 5002);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (5, 5003);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (5, 5004);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (5, 5005);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (5, 5006);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (5, 5007);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (5, 5008);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (5, 5009);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (5, 5010);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (5, 5011);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (5, 5012);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (5, 5013);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (5, 5014);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (5, 5015);

-- Show 6 (Interstellar - 3 PM at INOX Delhi)
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (6001, 1, false, 'AVAILABLE', 'PLATINUM', 550.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (6002, 1, false, 'AVAILABLE', 'PLATINUM', 550.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (6003, 1, false, 'AVAILABLE', 'PLATINUM', 550.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (6004, 1, false, 'AVAILABLE', 'PLATINUM', 550.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (6005, 1, false, 'AVAILABLE', 'PLATINUM', 550.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (6006, 1, false, 'AVAILABLE', 'PLATINUM', 550.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (6007, 2, false, 'AVAILABLE', 'GOLD', 450.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (6008, 2, false, 'AVAILABLE', 'GOLD', 450.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (6009, 2, false, 'AVAILABLE', 'GOLD', 450.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (6010, 2, false, 'AVAILABLE', 'GOLD', 450.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (6011, 3, false, 'AVAILABLE', 'SILVER', 350.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (6012, 3, false, 'AVAILABLE', 'SILVER', 350.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (6013, 3, false, 'AVAILABLE', 'SILVER', 350.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (6014, 3, false, 'AVAILABLE', 'SILVER', 350.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (6015, 3, false, 'AVAILABLE', 'SILVER', 350.00);

-- Associate Seats with Show 6
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (6, 6001);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (6, 6002);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (6, 6003);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (6, 6004);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (6, 6005);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (6, 6006);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (6, 6007);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (6, 6008);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (6, 6009);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (6, 6010);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (6, 6011);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (6, 6012);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (6, 6013);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (6, 6014);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (6, 6015);

-- Delhi - PVR Theatre - Show 7 (Raid - 10 AM)
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (7001, 1, false, 'AVAILABLE', 'PLATINUM', 475.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (7002, 1, false, 'AVAILABLE', 'PLATINUM', 475.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (7003, 1, false, 'AVAILABLE', 'PLATINUM', 475.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (7004, 1, false, 'AVAILABLE', 'PLATINUM', 475.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (7005, 2, false, 'AVAILABLE', 'GOLD', 375.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (7006, 2, false, 'AVAILABLE', 'GOLD', 375.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (7007, 2, false, 'AVAILABLE', 'GOLD', 375.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (7008, 2, false, 'AVAILABLE', 'GOLD', 375.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (7009, 2, false, 'AVAILABLE', 'GOLD', 375.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (7010, 3, false, 'AVAILABLE', 'SILVER', 275.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (7011, 3, false, 'AVAILABLE', 'SILVER', 275.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (7012, 3, false, 'AVAILABLE', 'SILVER', 275.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (7013, 3, false, 'AVAILABLE', 'SILVER', 275.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (7014, 3, false, 'AVAILABLE', 'SILVER', 275.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (7015, 3, false, 'AVAILABLE', 'SILVER', 275.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (7016, 3, false, 'AVAILABLE', 'SILVER', 275.00);

-- Associate Seats with Show 7
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (7, 7001);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (7, 7002);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (7, 7003);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (7, 7004);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (7, 7005);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (7, 7006);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (7, 7007);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (7, 7008);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (7, 7009);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (7, 7010);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (7, 7011);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (7, 7012);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (7, 7013);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (7, 7014);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (7, 7015);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (7, 7016);

-- Delhi - PVR Theatre - Show 8 (Raid - 3 PM)
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (8001, 1, false, 'AVAILABLE', 'PLATINUM', 475.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (8002, 1, false, 'AVAILABLE', 'PLATINUM', 475.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (8003, 1, false, 'AVAILABLE', 'PLATINUM', 475.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (8004, 1, false, 'AVAILABLE', 'PLATINUM', 475.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (8005, 2, false, 'AVAILABLE', 'GOLD', 375.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (8006, 2, false, 'AVAILABLE', 'GOLD', 375.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (8007, 2, false, 'AVAILABLE', 'GOLD', 375.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (8008, 2, false, 'AVAILABLE', 'GOLD', 375.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (8009, 2, false, 'AVAILABLE', 'GOLD', 375.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (8010, 3, false, 'AVAILABLE', 'SILVER', 275.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (8011, 3, false, 'AVAILABLE', 'SILVER', 275.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (8012, 3, false, 'AVAILABLE', 'SILVER', 275.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (8013, 3, false, 'AVAILABLE', 'SILVER', 275.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (8014, 3, false, 'AVAILABLE', 'SILVER', 275.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (8015, 3, false, 'AVAILABLE', 'SILVER', 275.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (8016, 3, false, 'AVAILABLE', 'SILVER', 275.00);

-- Associate Seats with Show 8
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (8, 8001);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (8, 8002);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (8, 8003);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (8, 8004);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (8, 8005);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (8, 8006);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (8, 8007);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (8, 8008);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (8, 8009);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (8, 8010);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (8, 8011);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (8, 8012);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (8, 8013);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (8, 8014);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (8, 8015);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (8, 8016);

-- Delhi - PVR Theatre - Show 9 (KGF - 10 AM)
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (9001, 1, false, 'AVAILABLE', 'PLATINUM', 525.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (9002, 1, false, 'AVAILABLE', 'PLATINUM', 525.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (9003, 1, false, 'AVAILABLE', 'PLATINUM', 525.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (9004, 1, false, 'AVAILABLE', 'PLATINUM', 525.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (9005, 1, false, 'AVAILABLE', 'PLATINUM', 525.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (9006, 2, false, 'AVAILABLE', 'GOLD', 425.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (9007, 2, false, 'AVAILABLE', 'GOLD', 425.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (9008, 2, false, 'AVAILABLE', 'GOLD', 425.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (9009, 2, false, 'AVAILABLE', 'GOLD', 425.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (9010, 2, false, 'AVAILABLE', 'GOLD', 425.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (9011, 2, false, 'AVAILABLE', 'GOLD', 425.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (9012, 3, false, 'AVAILABLE', 'SILVER', 325.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (9013, 3, false, 'AVAILABLE', 'SILVER', 325.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (9014, 3, false, 'AVAILABLE', 'SILVER', 325.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (9015, 3, false, 'AVAILABLE', 'SILVER', 325.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (9016, 3, false, 'AVAILABLE', 'SILVER', 325.00);
INSERT INTO seat (seat_id, seat_row, is_booked, seat_status, seat_category, price) VALUES (9017, 3, false, 'AVAILABLE', 'SILVER', 325.00);

-- Associate Seats with Show 9
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (9, 9001);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (9, 9002);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (9, 9003);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (9, 9004);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (9, 9005);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (9, 9006);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (9, 9007);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (9, 9008);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (9, 9009);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (9, 9010);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (9, 9011);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (9, 9012);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (9, 9013);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (9, 9014);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (9, 9015);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (9, 9016);
INSERT INTO show_seats (show_show_id, seats_seat_id) VALUES (9, 9017);

