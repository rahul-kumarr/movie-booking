# Book my Movie

Simple spring boot app to book the movies in a particular City.

## Overview
This application provides a RESTful API for movie ticket booking with optimized seat locking mechanism that mimics distributed Redis-based locking. The system is designed to handle concurrent booking requests efficiently while preventing race conditions and double bookings.
### Features
* Real-time seat availability: Track seat status in real-time
* Optimistic locking: Prevent concurrent bookings of the same seat
* Session-based booking: Temporary seat reservations with automatic expiration

## Technical Architecture
### Core Components
* Spring Boot Backend: RESTful API services
* In-memory Seat Locking: Mimics Redis-based distributed locking
* JPA/Hibernate: Database ORM for persistence
* Exception Handling: Global exception handler for consistent error responses

## Key Services

### BookingService: 
Manages the booking flow and transaction coordination
### SeatService: 
Handles seat locking, booking confirmation, and seat release
### PaymentService:
Processes payment for booked seats

Concurrency Management
The system uses a combination of techniques to handle concurrent booking requests:

### In-memory Distributed Locking: 
Using ConcurrentHashMap to mimic Redis-based locking
* Optimistic Locking: Version-based concurrency control
* Session-based Locks: Each booking attempt gets a unique session ID
* Automatic Lock Expiration: Prevents indefinite locking of seats
* Database Transactions: Ensures data consistency

 ## H2 DB access
open a browser and check your DB while running:
http://localhost:8080/h2-console
JDBC URL: jdbc:h2:mem:testdb
User: sa
No password

## APIs Swagger Link 
http://localhost:8080/swagger-ui/index.html


```
cd existing_repo
git remote add origin https://github.com/rahul-kumarr/movie-booking/tree/book-my-movie
git branch -M main
git push -uf origin main
```

